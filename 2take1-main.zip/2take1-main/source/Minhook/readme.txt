Each file name has these tags:

"x86", "x64":
    CPU archtecture

"v90", "v100", "v110", "v120", "v140", "v141":
    Platform toolset (compiler version)
    Choose "v110" for "v110_xp", "v120" for "v120_xp", "v140" for "v140_xp", "v141" for "v141_xp"

"md", "mt", "mdd", "mtd":
    Runtime Link (Dynamic/Static) and Config (Release/Debug)
    Corresponding to "/MD", "/MT", "/MDd" and "/MTd" compiler options respectively.
